<?php

$dbServername = "localhost"; 
$dbUsername = "id18739786_root"; 
$dbPassword = "#(LGx+SFH/~RQDU0"; 
$dbName = "id18739786_saghair";   
$conn = mysqli_connect( $dbServername, $dbUsername, $dbPassword, $dbName );  
?>
